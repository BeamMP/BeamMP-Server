queueExtensionToLoad("core/LuuksRadarMod")
