angular.module("beamng.apps")
.directive("luuksRadar", ["CanvasShortcuts", function (CanvasShortcuts) {
    return {
        template: '<canvas width="220"></canvas>',
        replace: true,
        restrict: "EA",
        link: function (scope, element, attrs) {
            var streamsList = ["LuuksRadar"];
            StreamsManager.add(streamsList);
            scope.$on("$destroy", function() {
                StreamsManager.remove(streamsList);
            });
            var c = element[0], ctx = c.getContext("2d");
            scope.$on('app:resized', function (event, data) {
                c.width = data.width
                c.height = data.height
            });
            scope.$on("streamsUpdate", function (event, streams) {
                function rotatedRect(
                    ctx,
                    x,
                    y,
                    w,
                    h,
                    rotation
                ) {
                    ctx.translate(x,y);
                    ctx.rotate(rotation);
                    ctx.translate(-x,-y);
                    ctx.strokeRect(x - w / 2, y - h / 2, w, h);
                    ctx.fillRect(x - w / 2, y - h / 2, w, h);
                    ctx.translate(x,y);
                    ctx.rotate(-rotation);
                    ctx.translate(-x,-y);
                }

                function drawCar(
                    ctx,
                    maxRange,
                    myYaw,
                    x,
                    y,
                    z,
                    width,
                    height,
                    rotation = 0,
                ) {
                    ctx.setTransform(1, 0, 0, 1, 0, 0); // No scaling, no skewing, no translation

                    var size = Math.min(c.width, c.height) / 2;
                    var scale = size / maxRange;
                    ctx.translate(c.width / 2, c.height / 2);
                    ctx.rotate(-myYaw);
                    ctx.translate(-c.width / 2, -c.height / 2);
                    ctx.scale(scale, scale);
                    ctx.translate(-dataStream.myPos.x, -dataStream.myPos.y);
                    ctx.translate(c.width / 2 / scale, c.height / 2 / scale);

                    rotatedRect(ctx, x, y, width, height, rotation);
                }

                function lerp(a,b,t) { return a + (b - a) * t; }

                var dataStream = streams.LuuksRadar;

                ctx.setTransform(1, 0, 0, 1, 0, 0); // No scaling, no skewing, no translation
                ctx.clearRect(0, 0, c.width, c.height);

                var size = Math.min(c.width, c.height) / 2;
                var scale = size / dataStream.range;

                ctx.lineWidth = 2;

                var globalOpacity = Math.min(Math.max((dataStream.closestDistance - (dataStream.range / 3)) / dataStream.range, 0), 1);
                globalOpacity = globalOpacity * globalOpacity;
                globalOpacity = 1.0 - globalOpacity;

                ctx.strokeStyle = "rgba(20,20,20," + globalOpacity + ")";

                ctx.beginPath();
                ctx.moveTo(c.width / 2, 0);
                ctx.lineTo(c.width / 2, c.height);
                ctx.stroke();

                ctx.beginPath();
                ctx.moveTo(0, c.height / 2);
                ctx.lineTo(c.width, c.height / 2);
                ctx.stroke();

                ctx.lineWidth = 4 / scale;

                var warnRight = dataStream.warnRight;

                ctx.fillStyle = "rgba(252, 198, 3," + warnRight + ")";
                ctx.strokeStyle = "rgba(252, 198, 3," + warnRight + ")";

                ctx.beginPath();
                ctx.moveTo(c.width / 2, c.height / 2);
                ctx.lineTo(c.width / 2 + c.width / 4, c.height / 3);
                ctx.lineTo(c.width / 2 + c.width / 4, c.height / 3 * 2);
                ctx.fill();

                var warnLeft = dataStream.warnLeft;

                ctx.fillStyle = "rgba(252, 198, 3," + warnLeft + ")";
                ctx.strokeStyle = "rgba(252, 198, 3," + warnLeft + ")";

                ctx.beginPath();
                ctx.moveTo(c.width / 2, c.height / 2);
                ctx.lineTo(c.width / 2 - c.width / 4, c.height / 3);
                ctx.lineTo(c.width / 2 - c.width / 4, c.height / 3 * 2);
                ctx.fill();

                ctx.fillStyle = "rgba(20,220,20," + globalOpacity + ")";
                ctx.strokeStyle = "rgba(20,20,20," + globalOpacity + ")";

                drawCar(
                    ctx,
                    dataStream.range,
                    dataStream.myYaw,
                    dataStream.myPos.x,
                    dataStream.myPos.y,
                    dataStream.myPos.z,
                    dataStream.myWidth,
                    dataStream.myLength,
                    dataStream.myYaw
                );

                for (let i = 0; i < dataStream.vehData.length; i++) {
                    var t = Math.min(((dataStream.vehData[i].dist - 3) / dataStream.range) * 2, 1);
                    var hue = lerp(0, 45, t);
                    ctx.fillStyle = "hsla(" + hue + ",100%,50%," + globalOpacity + ")";
                    ctx.strokeStyle = "rgba(20,20,20," + globalOpacity + ")";
                    drawCar(
                        ctx,
                        dataStream.range,
                        dataStream.myYaw,

                        dataStream.vehData[i].pos.x,
                        dataStream.vehData[i].pos.y,
                        dataStream.vehData[i].pos.z,

                        dataStream.vehData[i].width,
                        dataStream.vehData[i].length,
                        dataStream.vehData[i].yaw
                    )
                }
            });
        }
    }
}])
