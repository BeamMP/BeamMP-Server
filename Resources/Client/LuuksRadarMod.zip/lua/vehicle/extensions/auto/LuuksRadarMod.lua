local M = {}

M.vehData = {}
M.range = 25

-- TODO: I should absolutely replace these hand written math functions with the beam math functions lol
local function v3_distance(a, b)
    return math.sqrt(math.abs(a.x - b.x)^2 + math.abs(a.y - b.y)^2 + math.abs(a.z - b.z)^2)
end

local function v3_len(a)
    return math.sqrt(math.abs(a.x)^2 + math.abs(a.y)^2 + math.abs(a.z)^2)
end

local function v3_normalize(a)
    local l = v3_len(a)
    local r = {}
    r.x = a.x / l
    r.y = a.y / l
    r.z = a.z / l
    return r
end

local function v3_neg(a)
    local r = {}
    r.x = -a.x
    r.y = -a.y
    r.z = -a.z
    return r
end

local function v3_add(a, b)
    local r = {}
    r.x = a.x + b.x
    r.y = a.y + b.y
    r.z = a.z + b.z
    return r
end

local function v3_sub(a, b)
    local r = {}
    r.x = a.x - b.x
    r.y = a.y - b.y
    r.z = a.z - b.z
    return r
end

local function v3_mul(a, b)
    local r = {}
    r.x = a.x * b.x
    r.y = a.y * b.y
    r.z = a.z * b.z
    return r
end

local function v3_mul_f(a, b)
    local r = {}
    r.x = a.x * b
    r.y = a.y * b
    r.z = a.z * b
    return r
end

local function v3_div(a, b)
    local r = {}
    r.x = a.x / b.x
    r.y = a.y / b.y
    r.z = a.z / b.z
    return r
end

local function v3_div_f(a, b)
    local r = {}
    r.x = a.x / b
    r.y = a.y / b
    r.z = a.z / b
    return r
end

local function v3_lerp(a, b, t)
    local r = {}
    r.x = a.x + (b.x - a.x) * t
    r.y = a.y + (b.y - a.y) * t
    r.z = a.z + (b.z - a.z) * t
    return r
end

local function v3_dot(a, b)
    return a.x * b.x + a.y * b.y + a.z * b.z
end

local function v2_rot(a, rad)
    local c = math.cos(rad)
    local s = math.sin(rad)
    local r = deepcopy(a)
    r.x = c * a.x - s * a.y
    r.y = s * a.x + c * a.y
    return r
end

local function vecToString(v)
    return "{ x = " .. v.x .. ", y = " .. v.y .. ", z = " .. v.z .. " }"
end

local function vecToString2(v)
    return "vec3(" .. v.x .. ", " .. v.y .. ", " .. v.z .. ")"
end

local function updateGFX(dt)
    local objID = obj:getID()
    local pos = obj:getCenterPosition()
    local length = obj:getInitialLength()
    local width = obj:getInitialWidth()
    local roll, pitch, yaw = obj:getRollPitchYaw()
    local ourFrontPos = obj:getFrontPosition()
    local forward = obj:getForwardVector()

    if playerInfo.firstPlayerSeated then
        M.vehData[objID] = nil

        local right = v3_normalize({ x = forward.y, y = -forward.x, z = 0 })

        local carsLeft = {}
        local carsRight = {}

        local closestDistance = 99999999

        local stream = {}

        stream.range = M.range -- In meters
        stream.myPos = { x = -pos.x, y = pos.y, z = pos.z }
        stream.myLength = length
        stream.myWidth = width
        stream.myYaw = -yaw

        stream.vehData = {}
        for id, vehData in pairs(M.vehData) do
            local dist = v3_distance(stream.myPos, vehData.pos)
            vehData.dist = dist
            table.insert(stream.vehData, vehData)
            closestDistance = math.min(closestDistance, dist)

            if dist < 25 then
                local frontPos = deepcopy(vehData.fpos)
                local backPos = v3_add({ x = vehData.fpos.x, y = vehData.fpos.y, z = vehData.fpos.z }, v3_mul_f(vehData.fvec, vehData.length * -1.8))
                -- Translate the local points from car B space to car A space (we are car A)
                frontPos = v3_sub(frontPos, pos) -- Subtract our car position from the other car position
                frontPos = v2_rot(frontPos, -yaw)
                backPos = v3_sub(backPos, pos)
                backPos = v2_rot(backPos, -yaw)

                -- Now we check if the points are along side
                local leftDist = 99999
                local rightDist = 99999

                -- TODO: Perhaps replace the * 0.55 with * 0.5 + specific distance to prevent weird issues with large cars
                if frontPos.y > (length * -0.55) and frontPos.y < (length * 0.55) then
                    local sideDist = math.abs(frontPos.x)
                    if frontPos.x < 0 then
                        -- The car is on our right
                        rightDist = math.min(rightDist, sideDist)
                    else
                        -- The car is on our left
                        leftDist = math.min(leftDist, sideDist)
                    end
                end
                if backPos.y > (length * -0.55) and backPos.y < (length * 0.55) then
                    local sideDist = math.abs(backPos.x)
                    if backPos.x < 0 then
                        -- The car is on our right
                        rightDist = math.min(rightDist, sideDist)
                    else
                        -- The car is on our left
                        leftDist = math.min(leftDist, sideDist)
                    end
                end

                if leftDist < 99999 then
                    table.insert(carsLeft, leftDist)
                end
                if rightDist < 99999 then
                    table.insert(carsRight, rightDist)
                end
            end
        end

        stream.closestDistance = closestDistance

        local warnLeft = 1
        for i, dist in pairs(carsLeft) do
            print(dist)
            warnLeft = math.min(warnLeft, dist / 8)
        end
        stream.warnLeft = 1 - warnLeft

        local warnRight = 1
        for i, dist in pairs(carsRight) do
            warnRight = math.min(warnRight, dist / 8)
        end
        stream.warnRight = 1 - warnRight

        gui.send("LuuksRadar", stream)

        M.vehData = {}
    else
        M.vehData = {}
        local p = { x = -pos.x, y = pos.y, z = pos.z }
        local cmd = "LuuksRadarMod.vehData[" .. objID .. "] = { pos = " .. vecToString(p) .. ", fpos = " .. vecToString(ourFrontPos) .. ", fvec = " .. vecToString(forward) .. ", length = " .. length .. ", width = " .. width .. ", yaw = " .. -yaw .. " }"
        obj:queueGameEngineLua("be:getPlayerVehicle(0):queueLuaCommand(\"" .. cmd .. "\")")
    end
end

M.updateGFX = updateGFX
M.onReset = onReset

return M
